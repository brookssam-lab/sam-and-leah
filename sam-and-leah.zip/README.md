# Sam & Leah — PWA (Vite + React)

This is a starter Progressive Web App scaffold for the "Sam & Leah" app. It includes:
- React + Vite
- Firebase auth + Firestore integration skeleton
- FullCalendar integration
- Pages: Home, Calendar, Compliments, Food, Length of Service, Admin
- PWA manifest (vite-plugin-pwa) and placeholder icons

## Quick setup

1. Install dependencies
```bash
npm install
```

2. Create a Firebase project
 - Enable Email/Password auth in Authentication.
 - Create a Firestore database.
 - Add a Web App and copy the Firebase config.

3. Add environment variables (create `.env` in project root):
```
VITE_FIREBASE_API_KEY=your_api_key
VITE_FIREBASE_AUTH_DOMAIN=your_auth_domain
VITE_FIREBASE_PROJECT_ID=your_project_id
VITE_FIREBASE_STORAGE_BUCKET=your_storage_bucket
VITE_FIREBASE_MESSAGING_SENDER_ID=your_messaging_sender_id
VITE_FIREBASE_APP_ID=your_app_id
```

4. Replace the icons in `public/icons/` with proper 192x192 and 512x512 PNGs (the repo contains tiny placeholders).

5. Add some sample photos to `public/assets/random-photos/` (the repo includes tiny placeholders).

6. Start the dev server:
```bash
npm run dev
```

7. To build for production:
```bash
npm run build
```

## Deploy to Netlify

1. Push this repo to GitHub.
2. In Netlify, "New site from Git" -> connect your repo.
3. Build command: `npm run build`
4. Publish directory: `dist`
5. Add the VITE_* environment variables in Netlify site settings (same as your `.env`).

## Notes & TODOs
- Replace placeholder icons with real PNG files.
- Create initial users in Firebase Authentication, and create corresponding Firestore `users/{uid}` documents with `role` ("sam"/"leah"/"admin").
- The calendar prefill and advanced recurrence/exception handling are left as exercises — the skeleton supports rrule objects.
- For push notifications, set up FCM and Cloud Functions (not included).

If you'd like, I can:
- generate a GitHub-ready repo with a commit history (zip is ready to upload),
- or add a script to auto-create the initial calendar entries in Firestore using firebase-admin (requires service-account).